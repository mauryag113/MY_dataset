# Object Detection > 2024-12-27 8:53pm
https://universe.roboflow.com/sachin-maurya/object-detection-wmf11

Provided by a Roboflow user
License: CC BY 4.0

